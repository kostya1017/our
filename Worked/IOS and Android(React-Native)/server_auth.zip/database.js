var ForerunnerDB = require("forerunnerdb");

var fdb = new ForerunnerDB();
var db = fdb.db('xenforma');

